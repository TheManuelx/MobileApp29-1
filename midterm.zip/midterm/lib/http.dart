import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HttpPage extends StatefulWidget {
  const HttpPage({super.key});

  @override
  State<HttpPage> createState() => _HttpPageState();
}

class _HttpPageState extends State<HttpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amberAccent,
        title: const Text('FutureBuilder Page'),
      ),
      body: Center(
        child: FutureBuilder(
          future: fetchData(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Text('Result: ${snapshot.data}',
                  style: const TextStyle(fontSize: 40));
            } else if (snapshot.hasError) {
              return Text('${snapshot.error}');
            }
            return const CircularProgressIndicator();
          },
        ),
      ),
    );
  }

Future<String>  fetchData() async {
    final response =
        await http.get(Uri.parse('https://itpart.net/mobile/api/product0.php'));

    if (response.statusCode == 200){
      final JSONbody = json.decode(response.body);
      String strBody = response.body.toString();
      debugPrint(strBody);

      return strBody;
    } else {
      throw Exception('Problem....');
    }
}
}
